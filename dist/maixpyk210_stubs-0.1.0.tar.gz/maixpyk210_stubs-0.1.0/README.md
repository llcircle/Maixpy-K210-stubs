# Type stubs for MaixpyK210
为k210的maixpy提供类型提示，可以在vscode中编写代码时获得类型提示。
这个小项目由个人对照API文档结合ai工具编写，如有疏漏，欢迎指出。